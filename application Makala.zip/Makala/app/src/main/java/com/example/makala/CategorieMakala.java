package com.example.makala;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class CategorieMakala extends AppCompatActivity {

    private Button Categorie1;
    private Button Categorie2;
    private Button Categorie3;
    private Button Categorie4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categorie_makala);

        Categorie1 = (Button) findViewById(R.id.categorie1);
        Categorie2 = (Button) findViewById(R.id.categorie2);
        Categorie3 = (Button) findViewById(R.id.categorie3);
        Categorie4 = (Button) findViewById(R.id.categorie4);

        Categorie1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                _commande("1000");
            }
        });
        Categorie2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                _commande("5000");
            }
        });
        Categorie3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                _commande("10000");
            }
        });
        Categorie4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                _commande("22000");
            }
        });
    }

    private void _commande(String montant) {
        Intent intent = new Intent(CategorieMakala.this, Commande.class);
        intent.putExtra("Montant", montant);
        startActivity(intent);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_makala, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.Accueil:
                function_open_accueil();
                return true;
            case R.id.Categorie:
                function_open_categorie();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }



    private void function_open_categorie() {
        Intent intent = new Intent(getApplicationContext(), CategorieMakala.class);
        startActivity(intent);
    }

    private void function_open_accueil() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
    }
}