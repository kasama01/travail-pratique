package com.example.makala;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Commande extends AppCompatActivity {

    // pour faire la multiplication
    private TextView Montant;

    //le variable pour les input

    private EditText inputNoms;
    private  EditText inputQuartier;
    private EditText inputAvenue;
    private EditText inputNumero;
    private EditText inputTelephone;
    private EditText inputNombre;
    private Button buttonValide;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_commande);



        Montant = (TextView) findViewById(R.id.Montant);
        buttonValide = (Button) findViewById(R.id.buttonValider);

        inputNoms = (EditText) findViewById(R.id.inputNoms);
        inputQuartier = (EditText) findViewById(R.id.inputQuartier);
        inputAvenue = (EditText) findViewById(R.id.inputAvenue);
        inputNumero = (EditText) findViewById(R.id.inputNumero);
        inputTelephone = (EditText) findViewById(R.id.inputTelephone);
        inputNombre = (EditText) findViewById(R.id.inputNombre);

        // pour recuperer les donnes de l'activite Promotion
        Intent intent = getIntent();
        String mn = intent.getStringExtra("Montant").toString()+"Fc";
        Montant.setText((mn));


        buttonValide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                _verifier_commande(inputNoms.toString(), inputQuartier.toString(), inputAvenue.toString(),
                        inputNumero.toString(), inputTelephone.toString(), inputNombre.toString());
            }
        });
    }

    private void _verifier_commande(String Noms, String Quartier, String Avenue,
                                    String Numero, String Telephone, String Nombre) {

        Toast.makeText(this, "Commande envoyer.", Toast.LENGTH_SHORT).show();
    }
}