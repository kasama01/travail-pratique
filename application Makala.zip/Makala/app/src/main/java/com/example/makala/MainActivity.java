package com.example.makala;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button buttonDemarrer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonDemarrer = (Button) findViewById(R.id.buttonDemarrer);

        buttonDemarrer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                function_open_categorie();
            }
        });
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_makala, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.Accueil:
                function_open_accueil();
                return true;
            case R.id.Categorie:
                function_open_categorie();
                return true;

        }
        return super.onOptionsItemSelected(item);
    }



    private void function_open_categorie() {
        Intent intent = new Intent(getApplicationContext(), CategorieMakala.class);
        startActivity(intent);
    }

    private void function_open_accueil() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
    }
}